//
//  JioMeetCoreSDK.h
//  JioMeetCoreSDK
//
//  Created by Rohit41.Kumar on 16/11/23.
//

#import <Foundation/Foundation.h>

//! Project version number for JioMeetCoreSDK.
FOUNDATION_EXPORT double JioMeetCoreSDKVersionNumber;

//! Project version string for JioMeetCoreSDK.
FOUNDATION_EXPORT const unsigned char JioMeetCoreSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JioMeetCoreSDK/PublicHeader.h>


